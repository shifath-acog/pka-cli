
import sys
import os
from pyscf import gto
from pcm_opt_utils import get_atom_list, opti_PCM

def main():
    if len(sys.argv) != 2:
        print("Usage: python run_pcm_opt.py molecule.sdf")
        sys.exit(1)

    sdf_file = sys.argv[1]

    if not os.path.isfile(sdf_file):
        print(f"Error: File '{sdf_file}' not found.")
        sys.exit(1)

    # Extract base name without extension
    base_name = os.path.splitext(os.path.basename(sdf_file))[0]

    # ✅ Redirect STDOUT to .out file
    output_file = f"{base_name}.out"
    sys.stdout = open(output_file, 'w')
    sys.stderr = sys.__stderr__  # still show critical errors on screen

    # === Output filenames derived from input name ===
    xyz_output = f"{base_name}.xyz"
    charges_output = f"{base_name}.charge"

    # === User-configurable parameters ===
    eps = 46.826  # dielectric constant ; set to DMSO
    functional = "M06-2X"
    basis = "aug-cc-pvdz"
    charge = 0
    spin = 0

    # === Load atom list from sdf ===
    atom_list = get_atom_list(sdf_file)

    # === Build PySCF molecule ===
    mol = gto.Mole()
    mol.atom = atom_list
    mol.basis = basis
    mol.charge = charge
    mol.spin = spin
    mol.build()

    # === Run DFT-PCM optimization ===
    opti_PCM(mol, eps, xyz_output, charges_output, functional)

if __name__ == "__main__":
    main()
