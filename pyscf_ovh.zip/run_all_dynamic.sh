#!/bin/bash

# Number of consecutive checks where nothing is left to do before we exit
MAX_IDLE=5
IDLE_COUNT=0

while true; do
    any_pending=false

    for sdf in *.sdf; do
        out="${sdf%.sdf}.out"
        if [ ! -f "$out" ]; then
            echo "Running $sdf"
            python run_pcm_opt.py "$sdf"
            any_pending=true
        fi
    done

    if [ "$any_pending" = false ]; then
        ((IDLE_COUNT++))
        echo "Nothing to do. Idle count: $IDLE_COUNT/$MAX_IDLE"
    else
        IDLE_COUNT=0
    fi

    if [ "$IDLE_COUNT" -ge "$MAX_IDLE" ]; then
        echo "All jobs done. No new files found. Exiting."
        break
    fi

    sleep 60
done

