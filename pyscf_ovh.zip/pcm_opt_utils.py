
from rdkit import Chem
from pyscf import gto, dft
# from pyscf import rks
from gpu4pyscf.dft import rks
from pyscf.geomopt import geometric_solver
import time

def get_atom_list(sdf_file):
    molecules = Chem.SDMolSupplier(sdf_file, removeHs=False)
    mol = next(molecules)  # Assuming one molecule in SDF
    conformer = mol.GetConformer()

    atom_list = []
    for atom in mol.GetAtoms():
        pos = conformer.GetAtomPosition(atom.GetIdx())
        atom_list.append((atom.GetSymbol(), (pos.x, pos.y, pos.z)))
    return atom_list

def opti_PCM(mol, eps, xyz_filename, charge_filename, xc):
    start_time = time.time()

    mf = rks.RKS(mol).density_fit()
    mf.xc = xc
    mf.conv_tol = 1e-8
    mf.conv_tol_grad = 3e-4
    mf.max_cycle = 70

    mf = mf.PCM()
    mf.grids.atom_grid = (99, 590)
    mf.with_solvent.lebedev_order = 29
    mf.with_solvent.method = 'IEF-PCM'
    mf.with_solvent.eps = eps

    print("Starting geometry optimization...")
    mol_opt = geometric_solver.optimize(mf, max_steps=200, xtol=1e-8, gtol=3e-4, etol=1e-8)

    optimized_atoms = [(atom[0], mol_opt.atom_coords(unit='Angstrom')[i]) for i, atom in enumerate(mol_opt.atom)]

    mf_scf = rks.RKS(mol_opt).density_fit()
    mf_scf.xc = xc
    mf_scf.conv_tol = 1e-8
    mf_scf.conv_tol_grad = 3e-4
    mf_scf.max_cycle = 70

    mf_scf = mf_scf.PCM()
    mf_scf.grids.atom_grid = (99, 590)
    mf_scf.with_solvent.lebedev_order = 29
    mf_scf.with_solvent.method = 'IEF-PCM'
    mf_scf.with_solvent.eps = eps
    mf_scf.kernel()

    analysis = mf_scf.analyze()
    mulliken_charges = analysis[0][1]

    with open(charge_filename, "w") as charge_file:
        charge_file.write("Atom Index  Atom Symbol  Mulliken Charge\n")
        for i, charge in enumerate(mulliken_charges):
            atom_symbol = mol.atom_symbol(i)
            charge_file.write(f"{i+1}             {atom_symbol}        {charge:.6f}\n")

    final_energy_hartree = mf_scf.e_tot
    hartree_to_kcalmol = 627.509
    final_energy_kcalmol = final_energy_hartree * hartree_to_kcalmol

    with open(xyz_filename, 'w') as xyz_file:
        xyz_file.write(f"{len(optimized_atoms)}\n")
        xyz_file.write(f"Energy: {final_energy_kcalmol:.6f} kcal/mol\n")
        for symbol, coords in optimized_atoms:
            formatted_coords = ' '.join(f"{coord:.8f}" for coord in coords)
            xyz_file.write(f"{symbol} {formatted_coords}\n")

    print(f"Optimized geometry saved to '{xyz_filename}'.")
    print(f"Final energy: {final_energy_hartree:.8f} Hartree ({final_energy_kcalmol:.6f} kcal/mol)")
    print(f"\nOPT Time: {time.time() - start_time:.2f} seconds")
    print("################################################################")
    return mol_opt
